﻿Imports System.Text.RegularExpressions
Public Class Form1

    Public iClear As Integer = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If Me.TextBox1.Text <> String.Empty Then
            If Me.TextBox1.Text = "URL >>>" Then Exit Sub
            If ValidateUrl(Trim(Me.TextBox1.Text)) = True Then
                Dim command As String = String.Empty
                command = "c: && cd\Y && y.exe --extract-audio --audio-format mp3 --audio-quality 0 -i " & """" & Trim(Me.TextBox1.Text) & """"

                systemcmd(command)

                'URL Test https://www.youtube.com/watch?v=zqafF_gplmQ

            End If
        Else
            MsgBox("Insertar URL Valida", MsgBoxStyle.OkOnly, "Y-dl")
        End If

    End Sub

    Private Function ValidateUrl(ByVal sUrl As String) As Boolean
        Try
            Dim re As Regex = New Regex( _
            "^(https?|ftp|file)://[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|]", _
            RegexOptions.IgnoreCase)

            Dim m As Match = re.Match(Trim(sUrl))

            If m.Captures.Count = 0 Then
                MsgBox("La URL no es correcta", MsgBoxStyle.Critical, "Y-dl")
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, , "Y-dl")
            Return Nothing
        End Try
    End Function

    Private Sub systemcmd(ByVal cmd As String)
        Try
            Dim id As Integer = Shell("cmd /c """ & cmd & """", AppWinStyle.MaximizedFocus, True)
            MsgBox(CStr(id) & " Completado", MsgBoxStyle.Information, "Y-dl")
        Catch ex As Exception
            MsgBox("Error :(", MsgBoxStyle.Critical, "Y-dl")
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MinimumSize = Size
        Me.MaximumSize = Size
        Me.Label1.Text = "Y-dl"
        Me.TextBox1.Text = "URL >>>"
    End Sub

    Private Sub TextBox1_Click(sender As Object, e As EventArgs) Handles TextBox1.Click
        If iClear = 0 Then
            Me.TextBox1.Text = String.Empty
            iClear = 1
        End If
    End Sub

End Class
